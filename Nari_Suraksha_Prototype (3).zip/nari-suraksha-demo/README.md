# Nari Suraksha — Demo Prototype

A mobile-friendly, multilingual concept prototype for the Seva First Innovation Challenge.

## Included
- English, Hindi, and Marathi interface
- Emergency-options information (does not automatically call or send location)
- Travel check-in demo (page-only; no notification is sent)
- Trusted contact demo (kept in the current page; no server upload)
- Digital safety guidance
- Link to India's official ERSS 112 website

## Run locally
Open `index.html` in a modern browser.

## Publish as a public demo link with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `nari-suraksha-demo`.
2. Upload `index.html` to the repository's root (top-level folder).
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
5. Wait for GitHub Pages to publish. The public URL will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/nari-suraksha-demo/`
6. Open that URL in an incognito/private window to verify it works before submitting it.

## Important limitations
This is a demo prototype, not a live emergency response system. SOS does not contact police, location sharing is not implemented, check-ins do not notify contacts, and contact details are not saved on a server. Do not present these features as operational. Use only real, tested links in your application.
